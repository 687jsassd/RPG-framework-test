from abc import ABC, abstractmethod
from itertools import chain
from bisect import bisect_left, bisect_right
from collections import defaultdict
from syst.CONSTANT_LIST import *
from syst.base_func import *
import copy,uuid,logging
class Item(ABC):

    def __init__(self, name: str, description: str, consumable: bool = True, price: int = 0, sellable: bool = True, need_target: bool = True, quality: int = 1, durability: int = 1, max_durability: int = 1,owner=None,is_stackable=True):
        self.name = name
        self.description = description
        self.consumable = consumable
        self.sellable = sellable
        self.price = price
        self.need_target = need_target
        self.quality = quality
        self.durability = durability
        self.max_durability = max_durability
        self.owner=owner
        self.is_stackable=is_stackable
        self.uuid=uuid.uuid4()


        # 处理负数价格
        self.price = max(0, price)
        # 处理无意义耐久度
        self.max_durability = max(1, max_durability)
        self.durability = min(durability, max_durability)

    @abstractmethod
    def use(self, target: 'Character' = None) -> int:
        """使用物品的抽象方法"""
        pass

    def owner_change(self,target: 'Character' = None):
        if target == self.owner:
            print(USE_ITEM_ERROR_MESSAGES[-9])
        else:
            self.owner=target
    
    def get_basic_status(self, mode='display'):
        if mode == 'display':
            status_parts = [f'{convert_colorful_text(self.name, get_quality_color(self.quality))}:{self.description}']
            status_parts.append(f'|消耗品?:{self.consumable} |可出售?:{self.sellable} |价格:{self.price}')
            
            if isinstance(self, Equipment):
                status_parts.append(f'|耐久 {self.durability}/{self.max_durability}')
            else:
                status_parts.append(f'|使用次数 {self.durability}/{self.max_durability}')
                
            status_parts.append(f'|持有者:{self.owner}')
            return ' '.join(status_parts)
        else:
            return {
                'name': self.name,
                'description': self.description,
                'consumable': self.consumable,
                'sellable': self.sellable,
                'price': self.price,
                'quality': self.quality,
                'need_target': self.need_target,
                'durability': self.durability,
                'max_durability': self.max_durability,
                'owner': self.owner
            }

    def durability_down(self, value: int = 1):
        self.durability = max(0, self.durability - value)
        if self.durability <= 0:
            
            if isinstance(self, Equipment):
                if self.equipper:
                    self.equipper.unequip_item(self)
                self.owner.inventory.remove_item(self)

            return None
        else:
            return self

    def durability_up(self, value: int = 1):
        self.durability = min(self.max_durability, self.durability + value)
                

    def __str__(self) -> str:
        return convert_colorful_text(self.name, get_quality_color(self.quality)) 

    def __eq__(self, other):
        if not isinstance(other, Item):
            return False
        if self.is_stackable:
            self_dict = {k: v for k, v in self.__dict__.items() if k not in ['uuid', 'name', 'description']}
            other_dict = {k: v for k, v in other.__dict__.items() if k not in ['uuid', 'name', 'description']}
            return self_dict == other_dict
        else:
            return self.uuid == other.uuid

    def __lt__(self, other):  # 默认按字典序
        if isinstance(other, Item):
            return self.name < other.name
        return NotImplemented

    def __hash__(self):
        return hash(tuple(sorted(self.__dict__.items())))

    def __deepcopy__(self, memo):
        # 创建一个新的实例，不传递参数
        new_item = self.__class__()
        # 复制所有属性
        for key, value in self.__dict__.items():
            if key not in  ['uuid']:  # 排除uuid，因为它需要是唯一的
                setattr(new_item, key, copy.deepcopy(value, memo))
            if key in ['owner','equipper']:
                if value:
                    setattr(new_item, key, value.copy_with_same_uuid())
                else:
                    setattr(new_item, key, None)
        # 为新实例生成新的UUID
        new_item.uuid = uuid.uuid4()
        return new_item
class Equipment(Item):
    """
    Equipment 类表示游戏中的装备物品，继承自 Item 类。
    
    该类用于表示各种装备，包括武器、防具等，提供装备的基本属性和功能。
    
    核心功能包括：
    - 装备和卸下装备（use 方法）
    - 获取装备的基本状态信息（get_basic_status 方法）
    
    使用示例：
    
    构造函数参数：
    - name (str): 装备的名称，默认为 '空'。
    - description (str): 装备的描述，默认为 '无描述'。
    - equipment_type (str): 装备的类型，默认为 'none_test'。
    - bonuses (dict): 装备的属性加成字典，键为属性名，值为加成数值。
    - resistances (dict): 装备的属性抗性字典，键为属性名，值为抗性数值。
    - spe_effect_id (int): 特殊效果的 ID，默认为 0。
    - price (int): 装备的价格，默认为 0。
    - sellable (bool): 是否可出售，默认为 True。
    - durability (int): 装备的耐久度，默认为 100。
    - max_durability(int): 装备的最大耐久度，默认为 100。
    
    特殊使用限制或潜在的副作用：
    - 装备的使用和卸下需要目标角色（Character）实例。
    - 装备的耐久度会影响装备的可用性。
    """
    
    def __init__(
        self,
        name: str = '空',
        description: str = '无描述',
        equipment_type: str = 'none_test',
        bonuses: dict = None,
        resistances: dict = None,
        spe_effect_id: int = 0,
        price: int = 0,
        sellable: bool = True,
        durability: int = 100,
        max_durability: int = 100,
        quality: int = 0,
        is_stackable:bool = False):
        super().__init__(
            name=name,
            description=description,
            consumable=False,
            price=price,
            sellable=sellable,
            need_target=False,
            quality=quality,
            durability=durability,
            max_durability=max_durability,
            is_stackable=is_stackable
        )
        self.equipment_type = equipment_type
        self.bonuses = bonuses if bonuses is not None else {}
        self.resistances = resistances if resistances is not None else {}
        self.spe_effect_id = spe_effect_id
        self.is_equipped = False
        self.equipper= None

    def use(self, target:'Character'=None) -> int:
        if target is None:
            target=self.equipper
        if target is None and self.is_equipped:
            return -20
        if target is None and not self.is_equipped:
            target = self.owner
        if target is None:
            return -21
        if self.is_equipped:
            state = target.unequip_item(self)
            if state == 1:
                print(f"{target}卸下了 {self.name}")
                self.equipper=None
        else:
            state = target.equip_item(self)
            if state == 1:
                print(f"{target}装备了 {self.name}")
                self.equipper=target
        return state

    def get_basic_status(self, mode='display'):
        if mode == 'display':
            if self.equipment_type == 'none_test':
                return '无'
            status_parts = [f'{convert_colorful_text(self.name, get_quality_color(self.quality))}:{self.description}']
            for bonus, value in self.bonuses.items():
                color = RED if value < 0 else GREEN
                if bonus in ['crit', 'crit_dmg', 'eva']:
                    status_parts.append(f'|属性:{bonus.upper()} {color}{value*100:+.2f}%{RESET}')
                else:   
                    status_parts.append(f'|属性:{bonus.upper()} {color}{value:+.2f}{RESET}')
            for resistance, value in self.resistances.items():
                color = RED if value < 0 else GREEN
                status_parts.append(f'|抗性:{resistance.upper()} {color}{value*100:+.2f}%{RESET}')
        
            # 特殊效果
            if self.spe_effect_id != 0:
                status_parts.append(f'|特殊效果 {CYAN}{SPE_EFFECT_ID[self.spe_effect_id]}{RESET}')
        
            # 耐久
            durability_ratio = self.durability / self.max_durability
            if durability_ratio > 0.75:
                durability_color = GREEN
            elif durability_ratio > 0.5:
                durability_color = YELLOW
            elif durability_ratio > 0.25:
                durability_color = MAGENTA
            else:
                durability_color = RED
            status_parts.append(f'|耐久 {durability_color}{self.durability}/{self.max_durability}{RESET}')

            #持有者
            status_parts.append(f'||持有者 {self.owner}')
            
            if self.is_equipped:
                status_parts.append(f' |<{self.equipper}>已装备')
                
            return ' '.join(status_parts)
        else:
            return {
                'name': self.name,
                'description': self.description,
                'bonuses': self.bonuses,
                'resistances': self.resistances,
                'spe_effect_id': self.spe_effect_id,
                'durability': self.durability,
                'max_durability': self.max_durability,
                'quality': self.quality,
                'equipment_type': self.equipment_type,
                'is_equipped': self.is_equipped,
                'equipper': self.equipper,
                'owner': self.owner,
                'score': self.score
            }

class No_item(Item):
    #ID: 0
    """
    无物品类，继承自Item类，用于表示无物品的情况。
    """
    def __init__(self):
        """
        初始化无物品对象。
        """
        super().__init__(
            name='无物品',
            description='无物品(测试用)',
            consumable=False,
            price=0,
            sellable=False,
            quality=-1
        )
        
    def use(self, target: 'Character' = None) -> int:
        """
        使用无物品，由于无物品不可使用，因此打印提示信息并返回-1。
        
        :param target: 目标角色，默认为None
        :return: 始终返回-1
        """
        return -1
class Citem(Item):
    """
    Citem类是用于暂时存放新物品的类，当新物品尚未归入已有类时，可以使用此类。

    此类继承自Item类，并添加了一个特殊值属性spe_val。默认情况下，Citem物品是可消耗的，不可出售，且不需要指定目标。

    核心功能：
    - __init__：构造函数，用于初始化Citem对象。
    - use：使用Citem的方法，由于Citem是临时存放处，因此打印提示信息并返回-1。

    使用示例：

    构造函数参数：
    - name: 物品名称，类型为str。
    - description: 物品描述，类型为str。
    - consumable: 是否可消耗，类型为bool，默认为True。
    - price: 物品价格，类型为int，默认为0。
    - sellable: 是否可出售，类型为bool，默认为False。
    - need_target: 是否需要指定目标，类型为bool，默认为False。
    - spe_val: 特殊值，类型为int，默认为0。

    注意：
    - Citem是临时存放处，因此使用Citem时，不会对目标角色产生实际效果。
    - spe_val属性是可选的，用于存储额外的信息。
    """
    def __init__(self, name: str, description: str, consumable: bool = True, price: int = 0, sellable: bool = False, need_target: bool = False, spe_val:int = 0,quality:int = 0):
        super().__init__(name=name, description=description, consumable=consumable, price=price, sellable=sellable, need_target=need_target,quality=quality)
        self.spe_val = spe_val

    def use(self, target: 'Character' = None) -> int:
        """
        使用Citem，由于Citem是临时存放处，因此打印提示信息并返回-1。

        :param target: 目标角色，默认为None
        :return: 始终返回-1
        """
        return -1
class Heal_potion(Item):
    #ID: 1 - spe:heal_amount
    def __init__(self, heal_amount: int = 10,quality:int = 1):
        """
        初始化治疗药水对象

        :param heal_amount: 治疗药水回复的生命值，默认为10
        """
        #处理无意义回复:
        heal_amount=max(1,heal_amount)
        
        super().__init__(
            name=f'治疗药水({heal_amount})',
            description=f'回复{heal_amount}的生命值',
            price=int(2*pow(1.004,pow(heal_amount,0.50))+pow(heal_amount,1.33)),
            quality=quality
                         )
        self.heal_amount = heal_amount
    
    def use(self,target: 'Character' = None) ->int:
        """
        使用治疗药水回复目标的生命值

        :param target: 目标角色对象，默认为None
        :return: 使用治疗药水后的回复信息
        """
        if target.hp == target.max_hp:
            return -5
        else:
            actual_heal=target.heal(self.heal_amount)
            print(f"{target.name} healed for {actual_heal} HP.")
            return 1
class Dart(Item):
    #ID: 2 - spe: damage
    def __init__(self, damage: int = 5,quality: int =1):
        """
        初始化飞镖对象

        :param damage: 飞镖造成的伤害，默认为5
        """
        #处理无意义伤害:
        if damage <= 0:
            damage = 1
            
        super().__init__(
            name=f'飞镖({damage})',
            description=f'造成{damage}点伤害',
            price=int(3*pow(1.006,pow(damage,0.49))+pow(damage,1.33)),
            quality=quality,
            durability=2,
            max_durability=2
                         )
        self.damage = damage
    
    def use(self, target: 'Character' = None) ->int:
        """
        使用飞镖攻击目标

        :param target: 目标角色对象，默认为None
        :return: 使用飞镖后的攻击信息
        """
        actual_damage=target.take_damage(self.damage)
        #print(f"{target.name} was hit by a dart for {actual_damage} damage.")
        return 1

class Weapon(Equipment):
    """
    武器类，继承自装备类（Equipment），用于表示游戏中的武器。

    核心功能：
    - 初始化武器的基本属性，如名称、描述、属性加成字典、特殊效果ID、耐久度和价格。
    - 提供字符串表示形式，用于输出武器的类型。

    使用示例：
    weapon = Weapon(name="长剑", bonuses={'atk': 10}, price=100)
    print(weapon)  # 输出：武器

    构造函数参数：
    - name (str): 武器的名称，默认为"空武器"。
    - description (str): 武器的描述，默认为"无描述"。
    - bonuses (dict): 武器的属性加成字典，默认为空字典。
    - resistances (dict): 武器的属性抗性字典，默认为空字典。
    - spe_effect_id (int): 特殊效果ID，默认为0。
    - durability (int): 武器的耐久度，默认为100。
    - max_durability (int): 武器的最大耐久度，默认为100。
    - price (int): 武器的价格，默认为0。
    - sellable (bool): 武器是否可出售，默认为True。
    
    bonuses字典可用键:
    - 'atk': 攻击力加成
    - 'def': 防御力加成
    - 'max_hp': 最大HP加成
    """
    def __init__(self, name: str ='空武器', description: str = '无描述', bonuses: dict = None, resistances: dict = None,spe_effect_id: int = 0, durability: int = 100, max_durability: int =100, price: int = 0, sellable: bool = True,quality: int = 1):
        super().__init__(
            name=name,
            description=description,
            equipment_type='weapon',
            bonuses=bonuses,
            resistances=resistances,
            spe_effect_id=spe_effect_id,
            durability=durability,
            max_durability=max_durability,
            price=price,
            sellable=sellable,
            quality=quality
        )
class Armor(Equipment):
    def __init__(self, name: str = '空护甲', description: str = '无描述', quality: int = 1,bonuses: dict = None, resistances: dict = None,spe_effect_id: int = 0, durability: int = 100, max_durability: int =100, price: int = 0, sellable: bool = True):
        super().__init__(
            name=name,
            description=description,
            equipment_type='armor',
            bonuses=bonuses,
            resistances=resistances,
            price=price,
            sellable=sellable,
            spe_effect_id=spe_effect_id,
            durability=durability,
            max_durability=max_durability,
            quality=quality
        )
class Accessory(Equipment):
    def __init__(self, name: str = '空饰品', description: str = '无描述',quality:int = 1, bonuses: dict = None, resistances: dict = None,spe_effect_id: int = 0, durability: int = 100, max_durability: int = 100, price: int = 0, sellable: bool = True):
        super().__init__(
            name=name,
            description=description,
            equipment_type='accessory',
            bonuses=bonuses,
            resistances=resistances,
            price=price,
            sellable=sellable,
            spe_effect_id=spe_effect_id,
            durability=durability,
            max_durability=max_durability,
            quality=quality
        )
    
class Inventory:
    """
    Inventory 类用于管理物品库存。它允许添加、移除和获取物品，并支持按类型和消耗性过滤。

    核心功能：
    - 添加物品到库存
    - 从库存中移除物品
    - 获取库存中的消耗性物品
    - 获取库存中的所有物品
    - 获取特定名称的物品
    - 获取特定类型的物品

    使用示例：
    inventory = Inventory()
    inventory.add_item(item=Item("Apple"), quantity=5)
    inventory.remove_item(item=Item("Apple"), quantity=2)
    consumables = inventory.get_consumables()
    all_items = inventory.get_all()
    apple = inventory.get_item("Apple")
    fruits = inventory.get_item_of_type("Fruit")
    """

    def __init__(self):
        """
        初始化 Inventory 对象，创建一个空的物品字典。
        """
        self.items = {}

    def add_item(self, item: Item = None, quantity: int = 1) -> None:
        """
        向库存中添加物品。如果物品已存在，则增加其数量。

        参数：
        - item (Item): 要添加的物品对象，默认为 None。
        - quantity (int): 要添加的物品数量，默认为 1。
        """
        if item is None:
            item = No_item()  # 如果没有传入物品对象，则创建一个默认的 No_item 对象
        for existing_item in self.items:
            if item == existing_item:  # 检查物品是否已存在于库存中
                self.items[existing_item] += quantity  # 如果存在，增加物品数量
                return
        self.items[item] = quantity  # 如果物品不存在，则添加到库存中

    def remove_item(self, item: Item = None, quantity: int = 1) -> None:
        """
        从库存中移除物品。如果物品数量减少到零或以下，则从库存中删除该物品。

        参数：
        - item (Item): 要移除的物品对象，默认为 None。
        - quantity (int): 要移除的物品数量，默认为 1。
        """
        if item is None:
            return  # 如果没有传入物品对象，则直接返回
        if item in self.items:
            self.items[item] -= quantity  # 减少物品数量
            if self.items[item] <= 0:
                del self.items[item]  # 如果物品数量减少到零或以下，则从库存中删除该物品

    def get_consumables(self, mode: str = 'display') -> list[Item]:
        """
        获取库存中的消耗性物品。根据模式返回不同格式的结果。

        参数：
        - mode (str): 返回结果的模式，可以是 'display'、'all' 或其他，默认为 'display'。

        返回：
        - list[Item]: 根据模式返回的物品列表。
        """
        if mode == 'display':
            return [f"{item.name}*{self.items[item]}" for item in self.items if item.consumable]
        elif mode == 'all':
            return list(chain.from_iterable(
                [item]*qty for item, qty in self.items.items()
                ))
        else:
            return [item for item in self.items if item.consumable]

    def get_all(self, mode: str = 'display') -> list[Item]:
        """
        获取库存中的所有物品。根据模式返回不同格式的结果。

        参数：
        - mode (str): 返回结果的模式，可以是 'display'、'all' 或其他，默认为 'display'。

        返回：
        - list[Item]: 根据模式返回的物品列表。
        """
        if mode == 'display':
            return [f"{item.name}*{self.items[item]}" for item in self.items]
        elif mode == 'all':
            return list(chain.from_iterable(
                [item]*qty for item, qty in self.items.items()
                ))
        else:
            return [item for item in self.items]

    def get_item(self, item_name: str) -> Item:
        """
        获取特定名称的物品。

        参数：
        - item_name (str): 要获取的物品名称。

        返回：
        - Item: 对应名称的物品对象，如果不存在则返回 None。
        """
        for item in self.items:
            if item.name == item_name:
                return item
        return None

    def get_item_of_type(self, item_type: type, mode: str = 'all') -> list[Item]:
        """
        获取特定类型的物品。根据模式返回不同格式的结果。

        参数：
        - item_type (str): 要获取的物品类型。
        - mode (str): 返回结果的模式，可以是 'display'、'all' 或其他，默认为 'all'。

        返回：
        - list[Item]: 根据模式返回的物品列表。
        """
        if mode == 'all':
            return list(chain.from_iterable(
                [item]*qty for item, qty in self.items.items()
                if isinstance(item, item_type)
                ))
        elif mode == 'display':
            return [f"{item.name}*{self.items[item]}" for item in self.items if isinstance(item, item_type)]
        else:
            return [item for item in self.items if isinstance(item, item_type)]
class Inventory_improved:
    auto_sort_count=0

    def __init__(self,owner= None):

        self.subinventories = defaultdict(self.Subinventory)
        self.owner = owner
    
    class Subinventory:


        def __init__(self):
            """
            初始化 Subinventory 实例。

            参数：
            无
            """
            self.items = [] #格式:(特殊值,物品,数量)
        
        def _get_sort_key(self, item: Item) ->int :
            """
            根据物品类型定义排序规则。

            参数：
            item (Item): 要排序的物品实例

            返回：
            int: 排序键值
            """
            # 根据物品类型定义排序规则
            sort_key = INV_SORT_METHODS.get(type(item).__name__)
            return getattr(item, sort_key, 0) if sort_key else 0               # 其他物品不排序
            
        def add_item(self, item: Item, quantity: int = 1) -> None:
            """
            添加物品到库存。

            参数：
            item (Item): 要添加的物品实例
            quantity (int): 添加的数量，默认为1
            """
            if quantity<=0:
                return

            sort_key=self._get_sort_key(item)
            idx=bisect_left(self.items, (sort_key, item, 0))
            if idx<len(self.items) and self.items[idx][1]==item:
                self.items[idx]=(sort_key, item, self.items[idx][2]+quantity)
            else:
                self.items.insert(idx, (sort_key, item, quantity))

        def remove_item(self, item: Item, quantity: int = 1) -> None:
            """
            从库存中移除物品。

            参数：
            item (Item): 要移除的物品实例
            quantity (int): 移除的数量，默认为1
            """
            if quantity<=0:
                return
            for idx,i in enumerate(self.items):
                if item == i[1]:
                    self.items[idx]=(i[0],i[1],i[2]-quantity)
                    if self.items[idx][2]<=0:
                        del self.items[idx]
                    return
            return
        
        def catch_item(self, item: Item, quantity: int = 1) -> list:
            """
            从库存中拿取物品。

            参数：
            item (Item): 要拿取的物品实例
            quantity (int): 拿取的数量，默认为1
            """
            sort_key=self._get_sort_key(item)
            idx=bisect_left(self.items, (sort_key, item, 0))
            if idx<len(self.items) and self.items[idx][1]==item:
                _, existing_item, existing_qty = self.items[idx]
                if existing_qty <= quantity:
                    del self.items[idx]
                else:
                    self.items[idx]=(sort_key, item, existing_qty-quantity)
                return [existing_item for i in range(min(max(quantity,0),existing_qty))]
            else:
                return []
        
        def find_closet(self, target_val: int = 0) -> list:
            """
            查找最接近目标值的物品。

            参数：
            target_val (int): 目标值，默认为0

            返回：
            list: 最接近目标值的物品列表
            """
            keys= [x[0] for x in self.items]
            idx=bisect_left(keys, target_val)
            candidates = []
            if idx<len(keys):
                candidates.append(self.items[idx])
            if idx>0:
                candidates.append(self.items[idx-1])
            return candidates
        
        def get_all(self, mode: str = 'all') -> list[Item]:
            """
            获取所有物品的视图。

            参数：
            mode (str): 视图模式，默认为'all'，可选值为'all'、'display'、'all_items'

            返回：
            list: 物品视图列表
            """
            if mode == 'all':
                return [(sort_key, item, qty) for (sort_key, item, qty) in self.items]
            elif mode == 'display':
                return [f"{item.name} *{qty}" for _, item, qty in self.items]
            else:#all_items
                return list(chain.from_iterable(
                    [item]*qty for _, item, qty in self.items
                ))
                
        def get_exact_item(self, spe_val: int = 0, item: Item = None) -> Item:
            """
            获取特定物品。

            参数：
            spe_val (int): 特殊值，默认为0
            item (Item): 物品实例，默认为None

            返回：
            Item: 物品实例，如果未找到则返回None
            """
            if item is not None:
                spe_val=self._get_sort_key(item)
                idx=bisect_left(self.items, (spe_val, item, 0))
                if idx<len(self.items) and self.items[idx][1]==item:
                    return self.items[idx][1]
                else:
                    return None
            else:
                nums=[i[0] for i in self.items]
                idx=bisect_left(nums, spe_val)
                if idx<len(nums) and nums[idx]==spe_val:
                    return self.items[idx][1]
                else:
                    return None

        def auto_sort(self):
            if len(self.items) < 10:
                return
            if not self.items[0][1].is_stackable:
                return


            sorted_items = []
            current_item = self.items[0]
            count = self.items[0][2]

            for i in range(1, len(self.items)):
                if current_item[1]==self.items[i][1]:
                    count += 1
                else:
                    sorted_items.append((current_item[0], current_item[1], count))
                    current_item = self.items[i]
                    count = self.items[i][2]

            # 添加最后一个项目
            sorted_items.append((current_item[0], current_item[1], count))

            self.items = sorted_items

                
                
    def sub_sort(self,item_type = None):
        if not item_type:
            for i in self.subinventories:
                self.subinventories[i].auto_sort()
            return
        return self.subinventories[item_type].auto_sort()

    
    def idxit(self,item_type,idx):
        if item_type not in self.subinventories:
            print(USE_ITEM_ERROR_MESSAGES[-6])
            return None
        elif len(self.subinventories[item_type].items)<=idx:
            print(USE_ITEM_ERROR_MESSAGES[-31])
            return None
        return self.subinventories[item_type].items[idx][1]
    
    def add_item(self, item: Item, quantity: int = 1) -> None:
        if not item:
            return
        if not item.owner:
            item.owner=self.owner
            
        Inventory_improved.auto_sort_count+=1
        if Inventory_improved.auto_sort_count>=100:
            self.sub_sort()
            Inventory_improved.auto_sort_count=0
            
        if item.is_stackable:
            self.subinventories[type(item)].add_item(item, quantity)
        else:
            for i in range(quantity):
                new_item = copy.deepcopy(item)
                new_item.owner=item.owner
                self.subinventories[type(item)].add_item(new_item, 1)
            
    
    def remove_item(self, item: Item, quantity: int = 1) -> None:

        self.subinventories[type(item)].remove_item(item, quantity)
    
    def catch_remove_item(self, item: Item, quantity: int = 1) -> None:

        catched=self.subinventories[type(item)].catch_item(item, quantity)
        if catched:
            for i in range(len(catched)):
                itemcp=copy.deepcopy(catched[i])
                itemcp.owner=None
                catched[i]=itemcp
        return catched
    
    def get_items(self, item_type: type, spe_val: int = None, mode='all') ->list:
        """
        获取特定类型的物品。

        参数：
        item_type (type): 物品类型
        spe_val (int): 特殊值，默认为None
        mode (str): 视图模式，默认为'all'，可选值为'all'、'display'、'all_items'

        返回：
        list: 物品列表
        """
        if item_type not in self.subinventories:
            return []
        sub_inv=self.subinventories[item_type]
        if spe_val is None:
            if mode=='all':
                return[{
                    'value': c[0],
                    'item': c[1],
                    'quantity': c[2],
                    'description': c[1].description
                    } for c in sub_inv.get_all('all')
                ]
            else:
                return sub_inv.get_all(mode)
        else:
            if mode=='display':
                return[{
                    '名称': c[1].name,
                    '描述': c[1].description,
                    '耐久': f'{c[1].durability}/{c[1].max_durability}',
                    '数量': c[2],
                    '价格': c[1].price,
                    '可出售?': c[1].sellable,
                    } for c in sub_inv.find_closet(spe_val)
                ]
            else:
                return[{
                    'value': c[0],
                    'item': c[1],
                    'quantity': c[2],
                    'description': c[1].description
                } for c in sub_inv.find_closet(spe_val)
                ]
    
    def get_exact_item(self, spe_val: int = None, item_type: type = None, item: Item = None) -> Item:
        """
        获取特定物品。

        参数：
        spe_val (int): 特殊值，默认为None
        item_type (type): 物品类型，默认为None
        item (Item): 物品实例，默认为None

        返回：
        Item: 物品实例，如果未找到则返回None
        """
        if spe_val is not None and item_type is not None:
            return self.subinventories[item_type].get_exact_item(spe_val=spe_val)
        elif item is not None:
            item_type = type(item)
            return self.subinventories[item_type].get_exact_item(item=item)
        else:
            return None
    
    def get_all_items_view(self, mode: str = 'display') -> list:
        """
        获取所有物品的视图。

        参数：
        mode (str): 视图模式，默认为'display'，可选值为'display'、'all'

        返回：
        list: 物品视图列表
        """
        if mode == 'display':
            return [f"{item_type().__str__()} <{len(self.subinventories[item_type].items)}>" for item_type in self.subinventories.keys()]
        elif mode == 'all':
            return [item for item in self.subinventories.values()]
        
    def show_items_types(self, mode:str = 'all') -> list:
        """
        显示所有物品类型。

        参数：
        mode (str): 视图模式，默认为'all'，可选值为'all'、'display'

        返回：
        list: 物品类型列表
        """
        if mode=='all':
            return list(self.subinventories.keys())
        else:#display
            return [f"{item_type.__name__} <{len(self.subinventories[item_type].items)}>" for item_type in self.subinventories.keys()]
       
    def show_inventory(self,item_type=None):
        print(f"\n{self.owner}的背包：")
        if item_type is None:
            for item_type in self.subinventories.keys():
                if item_type().is_stackable:
                    print(f"{item_type.__name__} <{len(self.subinventories[item_type].items)}:{sum([item[2] for item in self.subinventories[item_type].items])}>:")
                else:
                    print(f"{item_type.__name__} <{len(self.subinventories[item_type].items)}>:")
                for idx,item in enumerate(self.subinventories[item_type].items):
                    if item[1].owner !=self.owner:
                        print(f'{RED}*[{idx}]{RESET}'+f'({item[2]}个)' +item[1].get_basic_status())
                    else:
                        print(f'[{idx}]'+f'({item[2]}个)' +item[1].get_basic_status())
        elif item_type in self.subinventories:
            if item_type().is_stackable:
                print(f"{item_type.__name__} <{len(self.subinventories[item_type].items)}:{sum([item[2] for item in self.subinventories[item_type].items])}>:")
            else:
                print(f"{item_type.__name__} <{len(self.subinventories[item_type].items)}>:")
            for idx,item in enumerate(self.subinventories[item_type].items):
                    if item[1].owner !=self.owner:
                        print(f'{RED}*[{idx}]{RESET}'+f'({item[2]}个)' +item[1].get_basic_status())
                    else:
                        print(f'[{idx}]'+f'({item[2]}个)' +item[1].get_basic_status())
                        
class Character:

    def __init__(self,
             name: str = f'{YELLOW}主角{RESET}',
             data: dict = {
                 'max_hp': 100,
                 'hp': 100,
                 'max_mp': 10,
                 'mp': 10,
                 'atk': 10,
                 'def': 0,
                 'spd': 5,
                 'lck': 1,
                 'crit': 0.05,
                 'crit_dmg': 1.5,
                 'eva': 0.05,
                 'lv':1,
                 'exp':0,
                 'lv_status_bonuses':{
                'max_hp': lambda x: x * 1 *int(1+pow(x,0.74)+pow(1.1,pow(x,0.5))),
                'hp': lambda x: x * 1 *int(1+pow(x,0.74)+pow(1.1,pow(x,0.5))),
                'max_mp': lambda x: x * 1 *int(1+pow(x,0.33)+pow(1.03,pow(x,0.5))),
                'mp': lambda x: x * 1 *int(1+pow(x,0.33)+pow(1.03,pow(x,0.5))),
                'atk': lambda x: x * 1*int(0.7+pow(x,0.25)+pow(1.02,pow(x,0.5))),
                'def': lambda x: x * 1 *int(1+pow(x,0.2)+pow(1.02,pow(x,0.5))),
                'spd': lambda x: x * 1 *int(1+pow(x,0.18)+pow(1.018,pow(x,0.5))),
                'lck': lambda x: x * 0 + 1*int(0.6+pow(x,0.3)),
                'crit': lambda x: x * 0 + 0.01*int(0.2+pow(x,0.6)),
                'crit_dmg': lambda x: x * 0 +0.02*int(0.5+pow(x,0.45)),
                'eva': lambda x: x * 0 + 0.01*int(0.31+pow(x,0.34)),},
                 'lv_resistance_bonuses':{
                'normal': lambda x: x * 0,
                'fire': lambda x: 0.01 *int(0.2+pow(x,0.5)),
                'ice': lambda x: 0.01 *int(0.2+pow(x,0.49)),
                'lightning': lambda x: 0.01 *int(0.2+pow(x,0.45)),
                'poison': lambda x: 0.01 *int(0.2+pow(x,0.45)),
                'dark': lambda x: 0.01 *int(0.2+pow(x,0.4)),},
                 },
             resistances: dict = {
                 'normal': 0,
                 'fire': 0,
                 },
             equipped: dict = {
                 'weapon': None,
                 'armor': None,
                 'accessory': None}
             ):

        self.name = name
        self.is_alive = True
        self.inventory = Inventory_improved(self)
        self.equipped = equipped.copy()
        self.uuid= uuid.uuid4()
        
        # 存储基础属性
        self._base_data = {
            'max_hp': data.get('max_hp', 100),
            'max_mp': data.get('max_mp', 10),
            'atk': data.get('atk', 10),
            'def': data.get('def', 0),
            'spd': data.get('spd', 5),
            'lck': data.get('lck', 1),
            'crit': data.get('crit', 0.05),
            'crit_dmg': data.get('crit_dmg', 1.5),
            'eva': data.get('eva', 0.05),
        }
        
        # 当前状态数据
        self._current_data = {
            'hp': data.get('hp', self._base_data['max_hp']),
            'mp': data.get('mp', self._base_data['max_mp']),
            'exp': data.get('exp', 0),
        }
        
        # 抗性数据
        self._base_resistances = resistances.copy()
        
        # 等级加成相关数据
        self._lv_status_bonuses_dic = data.get('lv_status_bonuses', {
            'max_hp': lambda x: x * 10,
            'hp': lambda x: x * 10,
            'max_mp': lambda x: x * 5,
            'mp': lambda x: x * 5,
            'atk': lambda x: x * 2,
            'def': lambda x: x * 1,
            'spd': lambda x: x * 1,
            'lck': lambda x: x * 0,
            'crit': lambda x: x * 0,
            'crit_dmg': lambda x: x * 0,
            'eva': lambda x: x * 0,    
        })
        self._lv_resistance_bonuses_dic = data.get('lv_resistance_bonuses', {
            'normal': lambda x: x * 0,
            'fire': lambda x: x * 0.01 *int(0.2+pow(x,0.5)),
            'ice': lambda x: x * 0.01 *int(0.2+pow(x,0.44)),
            'lightning': lambda x: x * 0.01 *int(0.2+pow(x,0.42)),
            'poison': lambda x: x * 0.01 *int(0.2+pow(x,0.4)),
        })
        
        # 初始化状态字典（可选，根据需求保留）
        self.base_status_dic = {
            'max_hp': self._base_data['max_hp'],
            'max_mp': self._base_data['max_mp'],
            'atk': self._base_data['atk'],
            'def': self._base_data['def'],
            'spd': self._base_data['spd'],
            'lck': self._base_data['lck'],
            'crit': self._base_data['crit'],
            'crit_dmg': self._base_data['crit_dmg'],
            'eva': self._base_data['eva'],
        }
        self.refresh_status()

    @property
    def hp(self):
        return self._current_data['hp']
    
    @hp.setter
    def hp(self, value):
        self._current_data['hp'] = max(0, min(value, self.max_hp))
        if self._current_data['hp'] <= 0:
            self.is_alive = False

    @property
    def mp(self):
        return self._current_data['mp']
    
    @mp.setter
    def mp(self, value):
        self._current_data['mp'] = max(0, min(value, self.max_mp))

    @property
    def exp(self):
        return self._current_data['exp']
    
    @exp.setter
    def exp(self, value):
        self._current_data['exp'] = max(0, value)

    @property
    def weapon(self):
        return self.equipped['weapon'] or Equipment()

    @property
    def armor(self):
        return self.equipped['armor'] or Equipment()

    @property
    def accessory(self):
        return self.equipped['accessory'] or Equipment()

    def equip_item(self, item: 'Equipment' = None) -> int:
        if item is None:
            return -2
        elif item.equipment_type not in self.equipped:
            return -12
        elif item.is_equipped and item.equipper == self:
            return -18
        elif item.is_equipped and item.equipper != self:
            return -17
        
        cur_equipment = self.equipped[item.equipment_type]
        if cur_equipment:
            cur_equipment.is_equipped = False
            cur_equipment.equipper = None
        self.equipped[item.equipment_type] = item
        item.is_equipped = True
        item.equipper = self
        self.refresh_status()
        return 1

    def unequip_item(self, item: 'Equipment' = None) -> int:
        if item is None:
            return -2
        elif item.equipment_type not in self.equipped:
            return -12
        elif self.equipped[item.equipment_type] != item:
            return -13
        elif not item.is_equipped:
            return -19
        elif item.equipper != self:
            return -16
        
        self.equipped[item.equipment_type] = None
        item.is_equipped = False
        item.equipper = None
        self.refresh_status()
        return 1

    def exp_curve_func(self, lv):
        top_m = int(1.03 ** pow(lv,0.1) * 100)
        ans= int(lv * pow(lv, 1.6) * top_m // 100)
        return ans * int(pow(lv/1000,pow(lv,0.002))) if lv>1000 else ans

    @property
    def lv(self):
        low, high = 1, 100000
        while low < high:
            mid = (low + high + 1) // 2
            if self.exp_curve_func(mid) <= self.exp:
                low = mid
            else:
                high = mid - 1
        return low

    @property
    def lv_status_bonuses(self):
        return {k: f(self.lv-1) for k, f in self._lv_status_bonuses_dic.items()}

    @property
    def lv_resistance_bonuses(self):
        return {k: f(self.lv-1) for k, f in self._lv_resistance_bonuses_dic.items()}

    def gain_exp(self, exp: int = 0):
        self.exp += exp
        self.refresh_status()

    @property
    def attack(self):
        equipment_bonus = sum(item.bonuses.get('atk',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('atk',0)
        return max(self._base_data['atk'] + equipment_bonus + lv_bonus, 0)

    @property
    def defence(self):
        equipment_bonus = sum(item.bonuses.get('def',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('def',0)
        return self._base_data['def'] + equipment_bonus + lv_bonus

    @property
    def max_hp(self):
        equipment_bonus = sum(item.bonuses.get('max_hp',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('max_hp',0)
        return max(self._base_data['max_hp'] + equipment_bonus + lv_bonus, 1)

    @property
    def speed(self):
        equipment_bonus = sum(item.bonuses.get('spd',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('spd',0)
        return max(self._base_data['spd'] + equipment_bonus + lv_bonus, 1)

    @property
    def max_mp(self):
        equipment_bonus = sum(item.bonuses.get('max_mp',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('max_mp',0)
        return max(self._base_data['max_mp'] + equipment_bonus + lv_bonus, 1)

    @property
    def luck(self):
        equipment_bonus = sum(item.bonuses.get('lck',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('lck',0)
        return self._base_data['lck'] + equipment_bonus + lv_bonus

    @property
    def crit(self):
        equipment_bonus = sum(item.bonuses.get('crit',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('crit',0)
        return min(max(self._base_data['crit'] + equipment_bonus + lv_bonus, 0), 1)

    @property
    def crit_dmg(self):
        equipment_bonus = sum(item.bonuses.get('crit_dmg',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('crit_dmg',0)
        return max(self._base_data['crit_dmg'] + equipment_bonus + lv_bonus, 0)

    @property
    def eva(self):
        equipment_bonus = sum(item.bonuses.get('eva',0) for item in self.equipped.values() if item)
        lv_bonus = self.lv_status_bonuses.get('eva',0)
        return min(max(self._base_data['eva'] + equipment_bonus + lv_bonus, 0), 0.9)

    @property
    def resistances(self):
        combined = self._base_resistances.copy()
        combined.update(self.lv_resistance_bonuses)
        for item in self.equipped.values():
            if item:
                for k, v in item.resistances.items():
                    combined[k] = combined.get(k, 0) + v
        for k in combined:
            combined[k] = min(combined[k], 0.99)
        return combined

    def take_damage(self, damage: int = 0) -> None:
        self.hp -= damage

    def take_mp_damage(self, damage: int = 0) -> None:
        self.mp -= damage

    def heal(self, val: int = 0) -> int:
        if not self.is_alive:
            return 0
        heal_amount = min(val, self.max_hp - self.hp)
        self.hp += heal_amount
        return heal_amount

    def heal_mp(self, val: int = 0) -> int:
        heal_amount = min(val, self.max_mp - self.mp)
        self.mp += heal_amount
        return heal_amount

    def revive(self, val: int = 1) -> int:
        if self.is_alive:
            return 0
        heal_amount = min(val, self.max_hp - self.hp)
        self.hp += heal_amount
        self.is_alive = True
        return heal_amount

    def attack_target(self, target: 'Character', type: str = 'normal') -> int:
        resistance = target.resistances.get(type, 0)
        actual_damage = max(int((self.attack - target.defence) * (1 - resistance)), 1)
        target.take_damage(actual_damage)
        self.refresh_status()
        return actual_damage

    def refresh_status(self):
        self.hp = min(self.hp, self.max_hp)
        self.mp = min(self.mp, self.max_mp)
        if self.exp >= self.exp_curve_func(self.lv + 1):
            self.hp = self.max_hp
            self.mp = self.max_mp
        for item in self.equipped.values():
            if item:
                if item.durability<=0:
                    self.unequip_item(item)  

    def use_item(self,item: Item = None, target: 'Character' = None,source:'Character'=None,) -> bool:
        """
        角色使用物品。

        参数：
        - source: 物品来源(角色,表示角色的仓库),用于删除旧物品和返回深拷贝的新物品
        - item: Item - 物品
        - target: Character - 目标角色

        返回值：
        - bool - 是否成功使用物品
        """
        if not item:
            print(USE_ITEM_ERROR_MESSAGES[-2])
            return False
        elif not source:
            source=item.owner
            if not source:
                print(USE_ITEM_ERROR_MESSAGES[-22])
                return False
            elif source != self:
                print(USE_ITEM_ERROR_MESSAGES[-8])
                return False
        elif not source.inventory.get_exact_item(item=item):
            print(USE_ITEM_ERROR_MESSAGES[-3])
            return False
        elif item.need_target and not target:
            print(USE_ITEM_ERROR_MESSAGES[-4])
            return False

        if item.consumable:
            item_for_use=copy.deepcopy(item)
            item_for_use.owner=None
        else:
            item_for_use=item
        state = item_for_use.use(target)
        if state == 1:
            if item.consumable:
                source.inventory.remove_item(item)
                after_item=item_for_use.durability_down(1)
                if after_item:
                    source.inventory.add_item(after_item)
                
            self.refresh_status()
            return True
        else:
            print(USE_ITEM_ERROR_MESSAGES[state])
            return False

    def use_more_items(self, items: list[Item] = None, targets: list['Character'] = None) -> bool:
        """
        角色使用多个物品。

        参数：
        - items: list[Item] - 物品列表
        - targets: list[Character] - 目标角色列表

        返回值：
        - bool - 是否成功使用物品
        """
        lth= len(items)
        if len(targets)==1:
            targets = [targets[0] for _ in range(lth)]
        elif len(targets)!=lth:
            print(USE_ITEM_ERROR_MESSAGES[-10])
            return False
            
        for i in range(len(items)):
            if not self.use_item(items[i], targets[i]):
                return False
        return True
            
    def use_item_fuzzy(self, item_type: type = None, target: 'Character' = None, spe_val: int = None) -> bool:
        """
        角色使用模糊匹配的物品。

        参数：
        - item_type: type - 物品类型
        - target: Character - 目标角色
        - spe_val: int - 特殊值

        返回值：
        - bool - 是否成功使用物品
        """
        if item_type is None:
            print(USE_ITEM_ERROR_MESSAGES[-7])
            return False
        elif item_type not in self.inventory.show_items_types():
            print(USE_ITEM_ERROR_MESSAGES[-6])
            return False
        else:
            item_to_use = self.inventory.get_exact_item(spe_val, item_type)
            if item_to_use is None:
                print(USE_ITEM_ERROR_MESSAGES[-3])
                candidates = self.inventory.get_items(item_type, spe_val)
                if len(candidates) != 0:
                    print("可选已有物品：")
                    for i, c in enumerate(candidates):
                        print(f"[{i}] {c['item'].get_basic_status()}||UUID:{c['item'].uuid}")
                    choice = int(input("请输入选项编号 或输入其他数字取消："))
                    if 0 <= choice < len(candidates):
                        item_to_use = candidates[choice]["item"]
                    else:
                        print("取消使用")
                        return False
                else:
                    return False
            self.use_item(item_to_use, target)



    def get_cur_status(self, turns: int = 0):
        self.refresh_status()
        if turns == 0:
            self.initial_status = {
                'max_hp': self.max_hp,
                'max_mp': self.max_mp,
                'atk': self.attack,
                'def': self.defence,
                'spd': self.speed,
                'lck': self.luck,
                'crit': self.crit,
                'crit_dmg': self.crit_dmg,
                'eva': self.eva,
                'resistances': self.resistances.copy(),
            }
            return f"{self.name} LV:{self.lv} ({self.exp}/{self.exp_curve_func(self.lv+1)} - EXP距升级:{self.exp_curve_func(self.lv+1) - self.exp}) \nHP:{self.hp}/{self.max_hp}, MP:{self.mp}/{self.max_mp} ||  ATK:{self.attack}, DEF:{self.defence}, SPD:{self.speed}, LCK:{self.luck}, CRIT:{self.crit}, CRIT_DMG:{self.crit_dmg}, EVA:{self.eva},\nRESISTANCES:{self.resistances}"
        cur_status = {
            'max_hp': self.max_hp,
            'max_mp': self.max_mp,
            'atk': self.attack,
            'def': self.defence,
            'spd': self.speed,
            'lck': self.luck,
            'crit': self.crit,
            'crit_dmg': self.crit_dmg,
            'eva': self.eva,
            'resistances': self.resistances.copy(),
        }
        if self.hp<=0.25*self.max_hp:
            hp_color=RED
        elif self.hp<=0.5*self.max_hp:
            hp_color=YELLOW
        elif self.hp<=0.75*self.max_hp:
            hp_color=GREEN
        else:
            hp_color=CYAN

        if self.mp<=0.25*self.max_mp:
            mp_color=RED
        elif self.mp<=0.5*self.max_mp:
            mp_color=YELLOW
        elif self.mp<=0.75*self.max_mp:
            mp_color=GREEN
        else:
            mp_color=CYAN
            
        status_parts = [f"{self.name} LV:{self.lv} ({self.exp}/{self.exp_curve_func(self.lv+1)} - EXP距升级:{self.exp_curve_func(self.lv+1) - self.exp}) \nHP:{hp_color}{self.hp}{RESET}/{self.max_hp}, MP:{mp_color}{self.mp}{RESET}/{self.max_mp} ||  ATK:{self.attack}, DEF:{self.defence}, SPD:{self.speed} \n"]
        changes = ['\n']

        for key in ['max_hp', 'max_mp', 'atk', 'def', 'spd', 'lck']:
            if self.initial_status[key] != cur_status[key]:
                change = -self.initial_status[key] + cur_status[key]
                color = RED if change < 0 else GREEN
                changes.append(f"属{key.upper()}:{color}{change:+d}{RESET}")

        for key in [ 'crit', 'crit_dmg', 'eva']:
            if self.initial_status[key] != cur_status[key]:
                change = -self.initial_status[key] + cur_status[key]
                color = RED if change < 0 else GREEN
                changes.append(f"属{key.upper()}:{color}{change*100:+.2f}%{RESET}")
        if len(changes)>1:
            changes.append('\n')
        for key, value in cur_status['resistances'].items():
            if self.initial_status['resistances'].get(key, 0) != value:
                change = -self.initial_status['resistances'].get(key, 0) + value
                color = RED if change < 0 else GREEN
                changes.append(f"抗{key.upper()}:{color}{change*100:+.2f}%{RESET}")

        if len(changes)>1:
            status_parts.append(" | ".join(changes))
            status_parts.append('\n')
        return " | ".join(status_parts)


    def get_cur_equipment(self):
        """
        获取角色当前装备。

        返回值：
        - str - 角色当前装备的字符串表示
        """
        self.refresh_status()
        return f"{self.name} \n武器:{self.weapon.get_basic_status(mode='display')}\n防具:{self.armor.get_basic_status(mode='display')}\n饰品:{self.accessory.get_basic_status(mode='display')}"


    def copy_with_same_uuid(self):
        """
        仅拷贝名称和uuid,用于识别所有者等
        """
        new_char = self.__class__(self.name)
        new_char.uuid = self.uuid
        return new_char
    
    def __str__(self) -> str:
        """
        返回角色的字符串表示。

        返回值：
        - str - 角色的字符串表示
        """
        return f"{self.name})"

    def __deepcopy__(self,memo):
        """
        用于深拷贝角色的方法。

        参数：
        - memo (dict) - 用于存储已经拷贝的对象的字典

        返回值：
        - Character - 拷贝后的角色对象
        """
        new_char = self.__class__(self.name)
        memo[id(self)]=new_char
        new_char.uuid = uuid.uuid4()
        for k,v in self.__dict__.items():
            if k not in ['uuid']:
                setattr(new_char,k,copy.deepcopy(v,memo))
        return new_char
        
    def __eq__(self, other):
        return self.uuid == other.uuid